<h1>The jQuery UI Month Picker</h1>

[![Build Status](https://travis-ci.org/KidSysco/jquery-ui-month-picker.svg?branch=master)](https://travis-ci.org/KidSysco/jquery-ui-month-picker)
[![Bower](https://img.shields.io/bower/v/jquery-ui-month-picker.svg)](https://github.com/KidSysco/jquery-ui-month-picker/wiki#installation)
[![Built with Grunt](https://cdn.gruntjs.com/builtwith.png)](http://gruntjs.com/)

<p>
 <b>jQuery UI Month Picker Home Page</b><br>
 <a href="https://kidsysco.github.io/jquery-ui-month-picker/">https://kidsysco.github.io/jquery-ui-month-picker/</a>
</p>

<p>
 <b>Getting started and Documentation</b><br>
 <a href="https://github.com/KidSysco/jquery-ui-month-picker/wiki">https://github.com/KidSysco/jquery-ui-month-picker/wiki</a>
</p>

<p>
 <b>jsFiddle with this Plugin</b><br>
 <a href="http://jsfiddle.net/kidsysco/JeZap/">http://jsfiddle.net/kidsysco/JeZap/</a>
</p>

<p>
 <b>Lead Programmer</b><br>
 <a href="https://github.com/benjamin-albert">Benjamin Albert</a>
</p>

<p>
 <b>Repo Maintenance and Gopher</b><br>
 <a href="https://github.com/KidSysco">Ryan Segura</a>
</p>
